import { useState } from "react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { Page, Card, BlockStack, InlineStack, Text, Select, Button, List } from "@shopify/polaris";
import { ExportIcon } from "@shopify/polaris-icons";
import { authenticate } from "../shopify.server";
import { SectionHeading } from "../components/StatTile";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  await authenticate.admin(request);
  return json({});
};

const PERIOD_OPTIONS = [
  { label: "Last 7 days", value: "7" },
  { label: "Last 30 days", value: "30" },
  { label: "Last 90 days", value: "90" },
];

export default function Reports() {
  useLoaderData<typeof loader>();
  const [days, setDays] = useState("30");

  return (
    <Page
      title="Profitability Report"
      subtitle="Download a report your client can open in Excel/Sheets, or send however you like"
      backAction={{ url: "/app" }}
    >
      <BlockStack gap="400">
        <Card>
          <BlockStack gap="400">
            <SectionHeading
              icon={ExportIcon}
              title="Download report"
              subtitle="A CSV with the period's summary numbers plus a full per-order profit breakdown."
            />
            <InlineStack gap="300" blockAlign="end" wrap={false}>
              <div style={{ minWidth: 220 }}>
                <Select
                  label="Period"
                  options={PERIOD_OPTIONS}
                  value={days}
                  onChange={setDays}
                />
              </div>
              {/* A plain anchor (via Button's url prop) triggers a real browser
                  download instead of a client-side route transition, since the
                  response is a CSV file with a Content-Disposition header. */}
              <Button url={`/app/reports/download?days=${days}`} variant="primary">
                Download CSV
              </Button>
            </InlineStack>
          </BlockStack>
        </Card>

        <Card>
          <BlockStack gap="200">
            <Text as="h3" variant="headingSm">
              What's in the file
            </Text>
            <List type="bullet">
              <List.Item>
                Summary totals: orders, delivered vs. RTO, revenue, net profit,
                margin, ad spend, and both gross and true (COD-adjusted) ROAS.
              </List.Item>
              <List.Item>
                One row per order with its full cost breakdown (COGS, delivery,
                RTO fee, cash handling, tax, packaging) and net profit — the
                same numbers shown on the Orders screen.
              </List.Item>
            </List>
            <Text as="p" tone="subdued">
              Opens cleanly in Excel, Google Sheets, or Numbers. Sharing it
              with a client by email or WhatsApp is just a matter of
              attaching the downloaded file — we can wire up automatic
              WhatsApp delivery later if you still want it.
            </Text>
          </BlockStack>
        </Card>
      </BlockStack>
    </Page>
  );
}
