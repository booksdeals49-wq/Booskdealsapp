import { useState } from "react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Form, useActionData, useLoaderData, useNavigation } from "@remix-run/react";
import {
  Page,
  Card,
  FormLayout,
  TextField,
  Button,
  BlockStack,
  InlineStack,
  Text,
  Banner,
  DataTable,
  Tabs,
  Badge,
  Box,
} from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import prisma from "../db.server";
import { fetchMetaDailySpend } from "../services/metaAds.server";
import { fetchTiktokDailySpend } from "../services/tiktokAds.server";
import { fetchSnapchatDailySpend } from "../services/snapchatAds.server";
import { fetchGoogleAdsDailySpend } from "../services/googleAds.server";

const PLATFORMS = ["meta", "google", "tiktok", "snapchat"] as const;
type Platform = (typeof PLATFORMS)[number];

const PLATFORM_LABEL: Record<Platform, string> = {
  meta: "Meta",
  google: "Google Ads",
  tiktok: "TikTok",
  snapchat: "Snapchat",
};

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;

  const connections = await prisma.adAccountConnection.findMany({ where: { shop } });
  const byPlatform: Record<Platform, { connected: boolean; accountId: string; extra: Record<string, string> }> =
    {
      meta: { connected: false, accountId: "", extra: {} },
      google: { connected: false, accountId: "", extra: {} },
      tiktok: { connected: false, accountId: "", extra: {} },
      snapchat: { connected: false, accountId: "", extra: {} },
    };
  for (const c of connections as Array<{ platform: string; accountId: string; extraJson: string | null }>) {
    if ((PLATFORMS as readonly string[]).includes(c.platform)) {
      byPlatform[c.platform as Platform] = {
        connected: true,
        accountId: c.accountId,
        extra: c.extraJson ? JSON.parse(c.extraJson) : {},
      };
    }
  }

  const recentSpendRows = await prisma.adSpend.findMany({
    where: { shop },
    orderBy: { date: "desc" },
    take: 200,
  });
  const recentSpend: Record<Platform, Array<{ date: string; spend: number }>> = {
    meta: [],
    google: [],
    tiktok: [],
    snapchat: [],
  };
  for (const r of recentSpendRows as Array<{ platform: string; date: Date; spend: number }>) {
    if ((PLATFORMS as readonly string[]).includes(r.platform) && recentSpend[r.platform as Platform].length < 14) {
      recentSpend[r.platform as Platform].push({ date: r.date as unknown as string, spend: r.spend });
    }
  }

  return json({ connections: byPlatform, recentSpend });
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const form = await request.formData();
  const intent = form.get("intent");
  const platform = String(form.get("platform") ?? "") as Platform;

  if (!(PLATFORMS as readonly string[]).includes(platform)) {
    return json({ ok: false, error: "Unknown platform." }, { status: 400 });
  }

  if (intent === "connect") {
    const accountId = String(form.get("accountId") ?? "").trim();

    if (platform === "google") {
      const developerToken = String(form.get("developerToken") ?? "").trim();
      const clientId = String(form.get("clientId") ?? "").trim();
      const clientSecret = String(form.get("clientSecret") ?? "").trim();
      const refreshTokenInput = String(form.get("refreshToken") ?? "").trim();
      if (!accountId || !developerToken || !clientId || !clientSecret) {
        return json(
          { ok: false, error: "Customer ID, developer token, client ID and client secret are all required." },
          { status: 400 },
        );
      }
      const existing = await prisma.adAccountConnection.findUnique({
        where: { shop_platform: { shop, platform } },
      });
      const refreshToken = refreshTokenInput || existing?.accessToken || "";
      if (!refreshToken) {
        return json({ ok: false, error: "Refresh token is required for a first-time connection." }, { status: 400 });
      }
      await prisma.adAccountConnection.upsert({
        where: { shop_platform: { shop, platform } },
        update: {
          accountId,
          accessToken: refreshToken,
          extraJson: JSON.stringify({ developerToken, clientId, clientSecret }),
        },
        create: {
          shop,
          platform,
          accountId,
          accessToken: refreshToken,
          extraJson: JSON.stringify({ developerToken, clientId, clientSecret }),
        },
      });
      return json({ ok: true, message: "Google Ads account connected." });
    }

    const accessToken = String(form.get("accessToken") ?? "").trim();
    const existing = await prisma.adAccountConnection.findUnique({
      where: { shop_platform: { shop, platform } },
    });
    if (!accountId || (!accessToken && !existing)) {
      return json(
        { ok: false, error: "Account ID and access token are both required." },
        { status: 400 },
      );
    }
    await prisma.adAccountConnection.upsert({
      where: { shop_platform: { shop, platform } },
      update: { accountId, accessToken: accessToken || existing?.accessToken || "" },
      create: { shop, platform, accountId, accessToken },
    });
    return json({ ok: true, message: `${PLATFORM_LABEL[platform]} ad account connected.` });
  }

  if (intent === "sync") {
    const connection = await prisma.adAccountConnection.findUnique({
      where: { shop_platform: { shop, platform } },
    });
    if (!connection) {
      return json({ ok: false, error: `Connect a ${PLATFORM_LABEL[platform]} ad account first.` }, { status: 400 });
    }
    try {
      let spend: Array<{ date: string; spend: number }>;
      if (platform === "meta") {
        spend = await fetchMetaDailySpend(connection.accessToken, connection.accountId, 30);
      } else if (platform === "tiktok") {
        spend = await fetchTiktokDailySpend(connection.accessToken, connection.accountId, 30);
      } else if (platform === "snapchat") {
        spend = await fetchSnapchatDailySpend(connection.accessToken, connection.accountId, 30);
      } else {
        const extra = connection.extraJson ? JSON.parse(connection.extraJson) : {};
        spend = await fetchGoogleAdsDailySpend(
          {
            developerToken: extra.developerToken ?? "",
            clientId: extra.clientId ?? "",
            clientSecret: extra.clientSecret ?? "",
            refreshToken: connection.accessToken,
            customerId: connection.accountId,
          },
          30,
        );
      }
      for (const day of spend) {
        if (!day.date) continue;
        await prisma.adSpend.upsert({
          where: {
            shop_platform_date_campaign: {
              shop,
              platform,
              date: new Date(day.date),
              campaign: "",
            },
          },
          update: { spend: day.spend },
          create: { shop, platform, date: new Date(day.date), spend: day.spend, campaign: "" },
        });
      }
      return json({ ok: true, message: `Synced ${spend.length} days of ${PLATFORM_LABEL[platform]} ad spend.` });
    } catch (e: any) {
      return json({ ok: false, error: e.message ?? "Sync failed." }, { status: 500 });
    }
  }

  return json({ ok: false, error: "Unknown action." }, { status: 400 });
};

function money(n: number) {
  return n.toFixed(2);
}

export default function AdSpend() {
  const { connections, recentSpend } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();
  const navigation = useNavigation();
  const busy = navigation.state === "submitting";

  const [selected, setSelected] = useState(0);
  const platform = PLATFORMS[selected];

  const tabs = PLATFORMS.map((p) => ({
    id: p,
    content: `${PLATFORM_LABEL[p]}${connections[p].connected ? " ✓" : ""}`,
  }));

  const totalAdSpendAllPlatforms = PLATFORMS.reduce(
    (sum, p) => sum + recentSpend[p].reduce((s, r) => s + r.spend, 0),
    0,
  );
  const connectedCount = PLATFORMS.filter((p) => connections[p].connected).length;

  return (
    <Page
      title="Ad Spend"
      subtitle="Connect your ad platforms to calculate true ROAS across all of them"
    >
      <BlockStack gap="400">
        <InlineStack gap="200">
          <Badge tone={connectedCount > 0 ? "success" : undefined}>
            {`${connectedCount} of ${PLATFORMS.length} platforms connected`}
          </Badge>
          {totalAdSpendAllPlatforms > 0 && (
            <Badge>{`${money(totalAdSpendAllPlatforms)} tracked spend (last 14 days shown, per platform)`}</Badge>
          )}
        </InlineStack>

        {actionData && "message" in actionData && actionData.message && (
          <Banner tone="success">{actionData.message}</Banner>
        )}
        {actionData && "error" in actionData && actionData.error && (
          <Banner tone="critical">{actionData.error}</Banner>
        )}

        <Card padding="0">
          <Tabs tabs={tabs} selected={selected} onSelect={setSelected} />
          <Box padding="400">
            <PlatformPanel
              platform={platform}
              connected={connections[platform].connected}
              accountId={connections[platform].accountId}
              extra={connections[platform].extra}
              recentSpend={recentSpend[platform]}
              busy={busy}
            />
          </Box>
        </Card>
      </BlockStack>
    </Page>
  );
}

function PlatformPanel({
  platform,
  connected,
  accountId,
  extra,
  recentSpend,
  busy,
}: {
  platform: Platform;
  connected: boolean;
  accountId: string;
  extra: Record<string, string>;
  recentSpend: Array<{ date: string; spend: number }>;
  busy: boolean;
}) {
  const [accountIdValue, setAccountIdValue] = useState(accountId);
  const [accessTokenValue, setAccessTokenValue] = useState("");
  const [developerToken, setDeveloperToken] = useState(extra.developerToken ?? "");
  const [clientId, setClientId] = useState(extra.clientId ?? "");
  const [clientSecret, setClientSecret] = useState(extra.clientSecret ?? "");
  const [refreshToken, setRefreshToken] = useState("");

  return (
    <BlockStack gap="400">
      <Form method="post" key={platform}>
        <input type="hidden" name="intent" value="connect" />
        <input type="hidden" name="platform" value={platform} />
        <FormLayout>
          {platform === "meta" && (
            <Text as="p" tone="subdued">
              Generate a long-lived access token for your ad account in Meta
              Events Manager / Graph API Explorer with the ads_read
              permission, then paste it here along with your ad account ID
              (found in Ads Manager, formatted like 123456789012345).
            </Text>
          )}
          {platform === "tiktok" && (
            <Text as="p" tone="subdued">
              From TikTok Ads Manager → Business Center → Developer Center,
              get an Access Token and your Advertiser ID for the ad account
              you want to track.
            </Text>
          )}
          {platform === "snapchat" && (
            <Text as="p" tone="subdued">
              From Snapchat Ads Manager → Business Details, get an OAuth
              access token and your Ad Account ID. Snapchat's standard tokens
              expire after ~30 minutes — you'll need to refresh and reconnect
              periodically until this is upgraded to full OAuth.
            </Text>
          )}
          {platform === "google" && (
            <Text as="p" tone="subdued">
              Google Ads needs four pieces: a developer token (approved by
              Google at ads.google.com/aw/apicenter — approval can take days
              to weeks), an OAuth client ID + secret (from a Google Cloud
              project), and a refresh token (from Google's OAuth consent
              flow), plus the target Customer ID.
            </Text>
          )}

          <TextField
            label={platform === "google" ? "Customer ID" : "Ad account ID"}
            name="accountId"
            autoComplete="off"
            value={accountIdValue}
            onChange={setAccountIdValue}
            placeholder={platform === "google" ? "1234567890" : "123456789012345"}
          />

          {platform === "google" ? (
            <>
              <TextField
                label="Developer token"
                name="developerToken"
                type="password"
                autoComplete="off"
                value={developerToken}
                onChange={setDeveloperToken}
              />
              <TextField
                label="OAuth client ID"
                name="clientId"
                autoComplete="off"
                value={clientId}
                onChange={setClientId}
              />
              <TextField
                label="OAuth client secret"
                name="clientSecret"
                type="password"
                autoComplete="off"
                value={clientSecret}
                onChange={setClientSecret}
              />
              <TextField
                label="Refresh token"
                name="refreshToken"
                type="password"
                autoComplete="off"
                value={refreshToken}
                onChange={setRefreshToken}
                placeholder={connected ? "•••••••• (leave blank to keep current token)" : ""}
              />
            </>
          ) : (
            <TextField
              label="Access token"
              name="accessToken"
              type="password"
              autoComplete="off"
              value={accessTokenValue}
              onChange={setAccessTokenValue}
              placeholder={connected ? "•••••••• (leave blank to keep current token)" : ""}
            />
          )}

          <Button submit loading={busy}>
            {connected ? `Update ${PLATFORM_LABEL[platform]} connection` : `Connect ${PLATFORM_LABEL[platform]}`}
          </Button>
        </FormLayout>
      </Form>

      {connected && (
        <BlockStack gap="300">
          <Form method="post">
            <input type="hidden" name="intent" value="sync" />
            <input type="hidden" name="platform" value={platform} />
            <Button submit loading={busy}>
              Sync last 30 days now
            </Button>
          </Form>

          {recentSpend.length > 0 && (
            <DataTable
              columnContentTypes={["text", "numeric"]}
              headings={["Date", "Spend"]}
              rows={recentSpend.map((r) => [new Date(r.date).toLocaleDateString(), money(r.spend)])}
            />
          )}
        </BlockStack>
      )}
    </BlockStack>
  );
}
