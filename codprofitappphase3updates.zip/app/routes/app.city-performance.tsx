import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { Page, Card, DataTable, BlockStack, Text, EmptyState } from "@shopify/polaris";
import { LocationIcon } from "@shopify/polaris-icons";
import { authenticate } from "../shopify.server";
import { getCityPerformance } from "../services/cityPerformance.server";
import { SectionHeading } from "../components/StatTile";

const DAYS = 30;

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const rows = await getCityPerformance(session.shop, DAYS);
  return json({ rows, currency: "USD" });
};

function money(n: number) {
  return n.toFixed(2);
}

export default function CityPerformance() {
  const { rows } = useLoaderData<typeof loader>();

  return (
    <Page
      title="City Performance"
      subtitle={`Last ${DAYS} days · profit and delivery reliability by city`}
      backAction={{ url: "/app" }}
    >
      <BlockStack gap="400">
        <Card>
          <BlockStack gap="300">
            <SectionHeading
              icon={LocationIcon}
              title="Performance by city"
              subtitle="Sorted by order volume — spot which cities drive profit and which quietly drain it through RTOs."
            />

            {rows.length === 0 ? (
              <EmptyState
                heading="No shipping city data yet"
                image="https://cdn.shopify.com/s/files/1/0757/9955/files/empty-state.svg"
              >
                <p>Once orders with a shipping city come in, they'll be broken down here.</p>
              </EmptyState>
            ) : (
              <DataTable
                columnContentTypes={[
                  "text",
                  "numeric",
                  "numeric",
                  "numeric",
                  "numeric",
                  "numeric",
                  "numeric",
                  "numeric",
                ]}
                headings={[
                  "City",
                  "Orders",
                  "Delivered",
                  "RTO",
                  "Delivery rate",
                  "RTO rate",
                  "Net profit",
                  "Avg order value",
                ]}
                rows={rows.map((r) => [
                  r.city,
                  String(r.orders),
                  String(r.delivered),
                  String(r.rto),
                  `${r.deliveryRatePercent.toFixed(1)}%`,
                  r.rtoRatePercent > 20 ? `⚠ ${r.rtoRatePercent.toFixed(1)}%` : `${r.rtoRatePercent.toFixed(1)}%`,
                  money(r.netProfit),
                  money(r.avgOrderValue),
                ])}
              />
            )}
          </BlockStack>
        </Card>

        {rows.length > 0 && (
          <Card>
            <BlockStack gap="200">
              <Text as="h3" variant="headingSm">
                Reading this report
              </Text>
              <Text as="p" tone="subdued">
                "Net profit" already accounts for your cost settings (COGS,
                delivery, RTO, cash handling, tax, packaging) per order — a
                city can have high revenue but low or negative net profit if
                its RTO rate is high. Cities with RTO rate above 20% are
                flagged.
              </Text>
            </BlockStack>
          </Card>
        )}
      </BlockStack>
    </Page>
  );
}
