// Resource route (no UI) — streams a downloadable CSV profitability report.
// Rendered as a plain link (not a Remix <Link>) from app.reports.tsx so the
// browser treats it as a normal file download via Content-Disposition,
// which works fine even inside the embedded app's iframe.

import type { LoaderFunctionArgs } from "@remix-run/node";
import { authenticate } from "../shopify.server";
import prisma from "../db.server";
import {
  computeOrderProfit,
  summarizeProfit,
  computeRoas,
  type CostSettings as CostSettingsType,
} from "../services/profit.server";

const DAY_MS = 24 * 60 * 60 * 1000;

type OrderRow = {
  orderNumber: string;
  orderId: string;
  totalPrice: number;
  subtotalPrice: number;
  isCod: boolean;
  isRto: boolean;
  lineItemsJson: string;
  city: string | null;
  createdAt: Date;
};

function csvCell(value: string | number): string {
  const s = String(value);
  if (s.includes(",") || s.includes('"') || s.includes("\n")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function csvRow(values: Array<string | number>): string {
  return values.map(csvCell).join(",") + "\r\n";
}

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;

  const url = new URL(request.url);
  const days = Math.max(1, Math.min(365, Number(url.searchParams.get("days") ?? 30) || 30));

  const [orders, costSettings, productCosts, adSpendRows] = await Promise.all([
    prisma.orderRecord.findMany({
      where: { shop, createdAt: { gte: new Date(Date.now() - days * DAY_MS) } },
      orderBy: { createdAt: "desc" },
    }),
    prisma.costSettings.upsert({ where: { shop }, update: {}, create: { shop } }),
    prisma.productCost.findMany({ where: { shop } }),
    prisma.adSpend.findMany({
      where: { shop, date: { gte: new Date(Date.now() - days * DAY_MS) } },
    }),
  ]);

  const settings: CostSettingsType = costSettings;
  const overrides = productCosts.map(
    (p: { variantId: string; costPerUnit: number }) => ({
      variantId: p.variantId,
      costPerUnit: p.costPerUnit,
    }),
  );

  const rows = orders as OrderRow[];
  const breakdowns = rows.map((o) =>
    computeOrderProfit(
      {
        orderId: o.orderId,
        totalPrice: o.totalPrice,
        subtotalPrice: o.subtotalPrice,
        isCod: o.isCod,
        isRto: o.isRto,
        lineItems: JSON.parse(o.lineItemsJson),
      },
      settings,
      overrides,
    ),
  );
  const summary = summarizeProfit(breakdowns, rows.map((o) => o.isRto));

  const totalAdSpend = (adSpendRows as Array<{ spend: number }>).reduce(
    (s, r) => s + r.spend,
    0,
  );
  const grossOrderRevenue = rows.reduce((s, o) => s + o.totalPrice, 0);
  const roas = computeRoas(grossOrderRevenue, summary.revenue, summary.netProfit, totalAdSpend);

  const currency = costSettings.currency;
  const generatedAt = new Date().toISOString();

  let csv = "";
  csv += csvRow([`COD Profit Report — ${shop}`]);
  csv += csvRow([`Period: last ${days} days`]);
  csv += csvRow([`Generated: ${generatedAt}`]);
  csv += csvRow([`Currency: ${currency}`]);
  csv += "\r\n";

  csv += csvRow(["Summary"]);
  csv += csvRow(["Orders", summary.orderCount]);
  csv += csvRow(["Delivered", summary.orderCount - summary.rtoCount]);
  csv += csvRow(["RTO", summary.rtoCount]);
  csv += csvRow(["RTO rate %", summary.rtoRatePercent.toFixed(2)]);
  csv += csvRow(["Revenue (realized)", summary.revenue.toFixed(2)]);
  csv += csvRow(["COGS (counted as loss)", summary.cogs.toFixed(2)]);
  csv += csvRow(["Delivery fees", summary.deliveryFees.toFixed(2)]);
  csv += csvRow(["RTO costs", summary.rtoCosts.toFixed(2)]);
  csv += csvRow(["Cash handling fees", summary.cashHandlingFees.toFixed(2)]);
  csv += csvRow(["Taxes", summary.taxes.toFixed(2)]);
  csv += csvRow(["Packaging fees", summary.packagingFees.toFixed(2)]);
  csv += csvRow(["Ad spend", totalAdSpend.toFixed(2)]);
  csv += csvRow(["Net profit", summary.netProfit.toFixed(2)]);
  csv += csvRow(["Margin %", summary.marginPercent.toFixed(2)]);
  csv += csvRow(["Gross ROAS", roas.grossRoas.toFixed(2)]);
  csv += csvRow(["True ROAS (COD-adjusted)", roas.trueRoas.toFixed(2)]);
  csv += "\r\n";

  csv += csvRow(["Order Detail"]);
  csv += csvRow([
    "Order",
    "Date",
    "City",
    "Status",
    "Order total",
    "COGS loss",
    "Delivery fee",
    "RTO fee",
    "Cash handling",
    "Tax",
    "Packaging",
    "Net profit",
    "Margin %",
  ]);
  rows.forEach((o, i) => {
    const b = breakdowns[i];
    csv += csvRow([
      o.orderNumber,
      new Date(o.createdAt).toISOString().slice(0, 10),
      o.city || "Unknown",
      o.isRto ? "RTO" : "Delivered/active",
      o.totalPrice.toFixed(2),
      b.cogsLoss.toFixed(2),
      b.deliveryFee.toFixed(2),
      b.rtoCost.toFixed(2),
      b.cashHandlingFee.toFixed(2),
      b.tax.toFixed(2),
      b.packagingFee.toFixed(2),
      b.netProfit.toFixed(2),
      b.marginPercent.toFixed(2),
    ]);
  });

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="profitability-report-${days}d-${new Date()
        .toISOString()
        .slice(0, 10)}.csv"`,
    },
  });
};
