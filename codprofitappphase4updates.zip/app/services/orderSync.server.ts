import prisma from "../db.server";
import type { LineItem } from "./profit.server";

// Shopify doesn't have a native "RTO" concept — merchants using COD apps
// conventionally mark returned-to-origin orders with a tag or cancel
// reason. We infer isRto from any of these signals, and merchants can also
// flip it manually from the Orders screen (see app.orders.tsx action).
const RTO_TAGS = ["rto", "return-to-origin", "returned", "undelivered"];
const COD_GATEWAY_HINTS = ["cash on delivery", "cod", "cashondelivery"];

export type ShopifyOrderPayload = {
  admin_graphql_api_id?: string;
  id: number | string;
  name: string;
  total_price: string;
  subtotal_price: string;
  currency: string;
  financial_status: string | null;
  fulfillment_status: string | null;
  cancel_reason?: string | null;
  tags?: string;
  payment_gateway_names?: string[];
  created_at: string;
  shipping_address?: { city?: string; country?: string } | null;
  source_name?: string | null;
  referring_site?: string | null;
  line_items: Array<{
    variant_id: number | string | null;
    product_id: number | string | null;
    title: string;
    quantity: number;
    price: string;
  }>;
};

function inferIsCod(payload: ShopifyOrderPayload): boolean {
  const gateways = (payload.payment_gateway_names || []).map((g) =>
    g.toLowerCase(),
  );
  return gateways.some((g) =>
    COD_GATEWAY_HINTS.some((hint) => g.includes(hint)),
  );
}

function inferIsRto(payload: ShopifyOrderPayload): boolean {
  const tags = (payload.tags || "")
    .split(",")
    .map((t) => t.trim().toLowerCase());
  if (tags.some((t) => RTO_TAGS.includes(t))) return true;
  if (payload.cancel_reason) {
    const reason = payload.cancel_reason.toLowerCase();
    if (reason.includes("declined") || reason.includes("undeliverable")) {
      return true;
    }
  }
  return false;
}

/** Upsert a local OrderRecord from a raw Shopify REST/webhook order payload. */
export async function syncOrderFromPayload(
  shop: string,
  payload: ShopifyOrderPayload,
) {
  const lineItems: LineItem[] = payload.line_items.map((li) => ({
    variantId: li.variant_id
      ? `gid://shopify/ProductVariant/${li.variant_id}`
      : "",
    productId: li.product_id
      ? `gid://shopify/Product/${li.product_id}`
      : "",
    title: li.title,
    quantity: li.quantity,
    price: Number(li.price),
  }));

  const orderId =
    payload.admin_graphql_api_id ?? `gid://shopify/Order/${payload.id}`;

  await prisma.orderRecord.upsert({
    where: { shop_orderId: { shop, orderId } },
    update: {
      totalPrice: Number(payload.total_price),
      subtotalPrice: Number(payload.subtotal_price),
      financialStatus: payload.financial_status,
      fulfillmentStatus: payload.fulfillment_status,
      isCod: inferIsCod(payload),
      isRto: inferIsRto(payload),
      city: payload.shipping_address?.city ?? null,
      country: payload.shipping_address?.country ?? null,
      channel: payload.source_name ?? null,
      referringSite: payload.referring_site ?? null,
      lineItemsJson: JSON.stringify(lineItems),
    },
    create: {
      shop,
      orderId,
      orderNumber: payload.name,
      totalPrice: Number(payload.total_price),
      subtotalPrice: Number(payload.subtotal_price),
      currency: payload.currency,
      financialStatus: payload.financial_status,
      fulfillmentStatus: payload.fulfillment_status,
      isCod: inferIsCod(payload),
      isRto: inferIsRto(payload),
      city: payload.shipping_address?.city ?? null,
      country: payload.shipping_address?.country ?? null,
      channel: payload.source_name ?? null,
      referringSite: payload.referring_site ?? null,
      lineItemsJson: JSON.stringify(lineItems),
      createdAt: new Date(payload.created_at),
    },
  });
}

/**
 * Backfill recent orders for a shop right after install via the Admin
 * GraphQL API, so the dashboard isn't empty until new webhooks arrive.
 * Call this from the app._index loader on first load, or a background job.
 */
export async function backfillRecentOrders(
  admin: { graphql: (query: string, opts?: any) => Promise<Response> },
  shop: string,
  days = 30,
) {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
  const response = await admin.graphql(
    `#graphql
    query BackfillOrders($query: String!) {
      orders(first: 100, query: $query, sortKey: CREATED_AT, reverse: true) {
        edges {
          node {
            id
            name
            createdAt
            displayFinancialStatus
            displayFulfillmentStatus
            cancelledAt
            cancelReason
            tags
            sourceName
            paymentGatewayNames
            currentTotalPriceSet { shopMoney { amount currencyCode } }
            subtotalPriceSet { shopMoney { amount } }
            shippingAddress { city countryCodeV2 }
            lineItems(first: 50) {
              edges {
                node {
                  title
                  quantity
                  originalUnitPriceSet { shopMoney { amount } }
                  variant { id }
                  product { id }
                }
              }
            }
          }
        }
      }
    }`,
    { variables: { query: `created_at:>=${since}` } },
  );

  const json = await response.json();
  const edges = json?.data?.orders?.edges ?? [];

  for (const { node } of edges) {
    const lineItems: LineItem[] = node.lineItems.edges.map((e: any) => ({
      variantId: e.node.variant?.id ?? "",
      productId: e.node.product?.id ?? "",
      title: e.node.title,
      quantity: e.node.quantity,
      price: Number(e.node.originalUnitPriceSet.shopMoney.amount),
    }));

    const tags = (node.tags || []).map((t: string) => t.toLowerCase());
    const gateways = (node.paymentGatewayNames || []).map((g: string) =>
      g.toLowerCase(),
    );

    await prisma.orderRecord.upsert({
      where: { shop_orderId: { shop, orderId: node.id } },
      update: {},
      create: {
        shop,
        orderId: node.id,
        orderNumber: node.name,
        totalPrice: Number(node.currentTotalPriceSet.shopMoney.amount),
        subtotalPrice: Number(node.subtotalPriceSet.shopMoney.amount),
        currency: node.currentTotalPriceSet.shopMoney.currencyCode,
        financialStatus: node.displayFinancialStatus,
        fulfillmentStatus: node.displayFulfillmentStatus,
        isCod: gateways.some((g: string) =>
          COD_GATEWAY_HINTS.some((hint) => g.includes(hint)),
        ),
        isRto: tags.some((t: string) => RTO_TAGS.includes(t)),
        city: node.shippingAddress?.city ?? null,
        country: node.shippingAddress?.countryCodeV2 ?? null,
        channel: node.sourceName ?? null,
        lineItemsJson: JSON.stringify(lineItems),
        createdAt: new Date(node.createdAt),
      },
    });
  }

  return edges.length;
}
