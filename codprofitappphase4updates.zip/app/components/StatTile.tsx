// Shared "icon badge + label/value" building blocks used across every
// screen (Dashboard stat cards, Orders summary tiles, section headings on
// Settings/Ad Spend/etc). Centralizing this fixes two things at once:
//   1. Alignment — a fixed-size, centered icon badge sitting directly next
//      to tightly-grouped label/value text, instead of a bare Icon (whose
//      SVG bounding box has uneven internal whitespace and reads as
//      "floating" away from its label).
//   2. Branding — every icon on every screen now inherits the app's navy
//      "financial" color (via Icon's tone="inherit") instead of Polaris's
//      default subdued gray, giving the app a consistent signature look.
import { BlockStack, InlineStack, Text, Icon } from "@shopify/polaris";
import type { IconSource } from "@shopify/polaris";
import { BRAND } from "./theme";

type Tone = "success" | "critical" | undefined;

const BADGE_BG: Record<"neutral" | "success" | "critical", string> = {
  neutral: BRAND.paleNavyBg,
  success: "#E4F3EE",
  critical: "#FAEAE8",
};

const BADGE_FG: Record<"neutral" | "success" | "critical", string> = {
  neutral: BRAND.navy,
  success: BRAND.profit,
  critical: BRAND.loss,
};

export function IconBadge({
  icon,
  tone,
  size = 36,
}: {
  icon: IconSource;
  tone?: Tone;
  size?: number;
}) {
  const key = tone ?? "neutral";
  return (
    <div
      style={{
        width: size,
        height: size,
        minWidth: size,
        borderRadius: 8,
        background: BADGE_BG[key],
        color: BADGE_FG[key],
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
      }}
    >
      <Icon source={icon} tone="inherit" />
    </div>
  );
}

export function SectionHeading({
  icon,
  title,
  subtitle,
}: {
  icon: IconSource;
  title: string;
  subtitle?: string;
}) {
  return (
    <InlineStack gap="300" blockAlign="center">
      <IconBadge icon={icon} />
      <BlockStack gap="0">
        <Text as="h2" variant="headingMd">
          {title}
        </Text>
        {subtitle && (
          <Text as="p" tone="subdued" variant="bodySm">
            {subtitle}
          </Text>
        )}
      </BlockStack>
    </InlineStack>
  );
}

// Compact tile: icon badge tightly grouped with a stacked label/value pair.
// Used for Orders' summary row and anywhere a small stat needs to sit in a
// horizontal row of cards.
export function StatTile({
  icon,
  label,
  value,
  tone,
}: {
  icon: IconSource;
  label: string;
  value: string;
  tone?: Tone;
}) {
  return (
    <InlineStack gap="300" blockAlign="center" wrap={false}>
      <IconBadge icon={icon} tone={tone} />
      <BlockStack gap="0">
        <Text as="span" tone="subdued" variant="bodySm">
          {label}
        </Text>
        <Text as="span" variant="headingMd" tone={tone}>
          {value}
        </Text>
      </BlockStack>
    </InlineStack>
  );
}

// Larger stat card used on the Dashboard, with an optional trend delta row.
export function StatCard({
  label,
  value,
  tone,
  icon,
  deltaPercent,
  deltaLabel = "vs previous 30 days",
  footnote,
}: {
  label: string;
  value: string;
  tone?: Tone;
  icon?: IconSource;
  deltaPercent?: number | null;
  deltaLabel?: string;
  // Plain subdued caption line — no arrow/percent styling. Used for context
  // that isn't a period-over-period delta (e.g. "AOV Rs 4,144.03").
  footnote?: string;
}) {
  return (
    <div
      style={{
        background: "#FFFFFF",
        border: "1px solid #E3E8EF",
        borderTop: `3px solid ${tone === "critical" ? BRAND.loss : tone === "success" ? BRAND.profit : BRAND.navy}`,
        borderRadius: 12,
        padding: "16px",
      }}
    >
      <BlockStack gap="200">
        <InlineStack gap="300" blockAlign="center" wrap={false}>
          {icon && <IconBadge icon={icon} tone={tone} />}
          <BlockStack gap="0">
            <Text as="span" tone="subdued" variant="bodySm">
              {label}
            </Text>
            <Text as="span" variant="headingLg" tone={tone}>
              {value}
            </Text>
          </BlockStack>
        </InlineStack>
        {deltaPercent !== undefined && deltaPercent !== null && (
          <Text
            as="span"
            variant="bodySm"
            tone={deltaPercent >= 0 ? "success" : "critical"}
          >
            {deltaPercent >= 0 ? "▲" : "▼"} {Math.abs(deltaPercent).toFixed(1)}% {deltaLabel}
          </Text>
        )}
        {footnote && (
          <Text as="span" variant="bodySm" tone="subdued">
            {footnote}
          </Text>
        )}
      </BlockStack>
    </div>
  );
}
