import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import {
  Page,
  Card,
  BlockStack,
  InlineStack,
  InlineGrid,
  Text,
  Button,
  DataTable,
  Badge,
  Divider,
} from "@shopify/polaris";
import {
  ExportIcon,
  OrderIcon,
  ChartLineIcon,
  CashDollarIcon,
  WalletIcon,
  ReceiptIcon,
  ChartHistogramGrowthIcon,
  MegaphoneIcon,
  PersonIcon,
  GlobeIcon,
  ProductIcon,
} from "@shopify/polaris-icons";
import { authenticate } from "../shopify.server";
import { resolveDateRange } from "../utils/dateRange.server";
import { getRangeSummary } from "../services/rangeSummary.server";
import { getCostBreakdown } from "../services/costBreakdown.server";
import { getChannelPerformance } from "../services/channelPerformance.server";
import { getProductDelivery } from "../services/productDelivery.server";
import { StatCard, SectionHeading } from "../components/StatTile";
import { CostBreakdownPanel, NetProfitWaterfall } from "../components/CostBreakdownPanels";
import { DateRangePicker } from "../components/DateRangePicker";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const url = new URL(request.url);
  const range = resolveDateRange(url);

  const [rangeSummary, costBreakdown, channelPerformance, productDelivery] = await Promise.all([
    getRangeSummary(shop, range.from, range.to),
    getCostBreakdown(shop, range.from, range.to),
    getChannelPerformance(shop, range.from, range.to),
    getProductDelivery(shop, range.from, range.to),
  ]);

  return json({
    range,
    rangeSummary,
    costBreakdown,
    channelPerformance,
    productDelivery,
  });
};

function money(n: number, currency: string) {
  try {
    return new Intl.NumberFormat(undefined, {
      style: "currency",
      currency,
      maximumFractionDigits: 2,
    }).format(n);
  } catch {
    return `${currency} ${n.toFixed(2)}`;
  }
}

const PERFORMANCE_TONE: Record<string, "success" | "warning" | "critical"> = {
  good: "success",
  average: "warning",
  poor: "critical",
};
const PERFORMANCE_LABEL: Record<string, string> = {
  good: "Good performance",
  average: "Average performance",
  poor: "Poor performance",
};

export default function Reports() {
  const { range, rangeSummary, costBreakdown, channelPerformance, productDelivery } =
    useLoaderData<typeof loader>();
  const currency = rangeSummary.currency;

  return (
    <Page
      title="Reports"
      subtitle="Range metrics, cost & profit breakdown, channel and product performance — all for one date range"
      backAction={{ url: "/app" }}
    >
      <BlockStack gap="500">
        <Card>
          <BlockStack gap="300">
            <InlineStack align="space-between" blockAlign="center" wrap>
              <Text as="h2" variant="headingMd">
                {range.fromLabel} to {range.toLabel}
              </Text>
              <Button
                icon={ExportIcon}
                url={`/app/reports/download?from=${range.fromLabel}&to=${range.toLabel}`}
              >
                Download CSV
              </Button>
            </InlineStack>
            <DateRangePicker fromLabel={range.fromLabel} toLabel={range.toLabel} />
          </BlockStack>
        </Card>

        <BlockStack gap="300">
          <Text as="h2" variant="headingMd">
            Range metrics
          </Text>
          <InlineGrid columns={{ xs: 1, sm: 2, md: 4 }} gap="400">
            <StatCard
              label="Total orders"
              value={String(rangeSummary.orderCount)}
              icon={OrderIcon}
              footnote={`${rangeSummary.rtoCount} returned · ${rangeSummary.rtoRatePercent.toFixed(1)}% RTO rate`}
            />
            <StatCard
              label="Total revenue (gross)"
              value={money(rangeSummary.grossRevenue, currency)}
              icon={ChartLineIcon}
              footnote={`AOV ${money(rangeSummary.aov, currency)}`}
            />
            <StatCard
              label="Net profit (realized)"
              value={money(rangeSummary.netProfitAfterAdSpend, currency)}
              tone={rangeSummary.netProfitAfterAdSpend >= 0 ? "success" : "critical"}
              icon={CashDollarIcon}
              footnote="After ad spend, from delivered orders"
            />
            <StatCard
              label="Profit / order"
              value={money(rangeSummary.profitPerOrder, currency)}
              tone={rangeSummary.profitPerOrder >= 0 ? "success" : "critical"}
              icon={ReceiptIcon}
            />
            <StatCard
              label="Total costs"
              value={money(costBreakdown.totalCostsInclAdSpend, currency)}
              icon={WalletIcon}
              footnote="Product + fees + shipping + ad spend"
            />
            <StatCard
              label="ROAS (return on ad spend)"
              value={`${rangeSummary.roas.trueRoas.toFixed(2)}x`}
              tone={
                rangeSummary.totalAdSpend > 0 && rangeSummary.roas.trueRoas < 1
                  ? "critical"
                  : undefined
              }
              icon={ChartHistogramGrowthIcon}
              footnote={`Gross ROAS ${rangeSummary.roas.grossRoas.toFixed(2)}x`}
            />
            <StatCard
              label="Total ad spend"
              value={money(rangeSummary.totalAdSpend, currency)}
              icon={MegaphoneIcon}
              footnote={`${costBreakdown.adSpendByPlatform.length} platform${costBreakdown.adSpendByPlatform.length === 1 ? "" : "s"}`}
            />
            <StatCard
              label="Blended CAC"
              value={money(rangeSummary.blendedCac, currency)}
              icon={PersonIcon}
              footnote="Ad spend ÷ total orders"
            />
          </InlineGrid>
        </BlockStack>

        <InlineGrid columns={{ xs: 1, lg: 2 }} gap="400">
          <Card>
            <BlockStack gap="300">
              <SectionHeading icon={WalletIcon} title="Costs breakdown" />
              <CostBreakdownPanel data={costBreakdown} money={money} />
            </BlockStack>
          </Card>
          <Card>
            <BlockStack gap="300">
              <SectionHeading icon={CashDollarIcon} title="Net profit (realized) breakdown" />
              <NetProfitWaterfall data={costBreakdown} money={money} />
            </BlockStack>
          </Card>
        </InlineGrid>

        <Card>
          <BlockStack gap="400">
            <SectionHeading
              icon={GlobeIcon}
              title="Channel-wise performance"
              subtitle="Classified from the referring link captured at checkout — new orders only (see note below)."
            />
            {channelPerformance.length === 0 ? (
              <Text as="p" tone="subdued">
                No orders in this range yet.
              </Text>
            ) : (
              <InlineGrid columns={{ xs: 1, sm: 2, md: 3 }} gap="400">
                {channelPerformance.map((row) => (
                  <div
                    key={row.channel}
                    style={{
                      border: "1px solid #E3E8EF",
                      borderRadius: 12,
                      padding: 16,
                    }}
                  >
                    <BlockStack gap="200">
                      <InlineStack align="space-between" blockAlign="center">
                        <Text as="span" variant="headingSm">
                          {row.channel}
                        </Text>
                        <Badge tone={PERFORMANCE_TONE[row.performance]}>
                          {PERFORMANCE_LABEL[row.performance]}
                        </Badge>
                      </InlineStack>
                      <Text as="span" tone="subdued" variant="bodySm">
                        {row.orders} total orders
                      </Text>
                      <BlockStack gap="050">
                        <InlineStack align="space-between">
                          <Text as="span" variant="bodySm" tone="subdued">
                            Delivery rate
                          </Text>
                          <Text as="span" variant="bodySm" fontWeight="medium">
                            {row.deliveryRatePercent.toFixed(1)}%
                          </Text>
                        </InlineStack>
                        <div style={{ background: "#EEF2F7", borderRadius: 4, height: 6 }}>
                          <div
                            style={{
                              width: `${Math.min(row.deliveryRatePercent, 100)}%`,
                              background: "#0F6E5C",
                              height: 6,
                              borderRadius: 4,
                            }}
                          />
                        </div>
                      </BlockStack>
                      <BlockStack gap="050">
                        <InlineStack align="space-between">
                          <Text as="span" variant="bodySm" tone="subdued">
                            RTO rate
                          </Text>
                          <Text as="span" variant="bodySm" fontWeight="medium">
                            {row.rtoRatePercent.toFixed(1)}%
                          </Text>
                        </InlineStack>
                        <div style={{ background: "#EEF2F7", borderRadius: 4, height: 6 }}>
                          <div
                            style={{
                              width: `${Math.min(row.rtoRatePercent, 100)}%`,
                              background: "#A1291E",
                              height: 6,
                              borderRadius: 4,
                            }}
                          />
                        </div>
                      </BlockStack>
                      <Divider />
                      <Text as="span" variant="headingSm">
                        {money(row.avgOrderValue, currency)}{" "}
                        <Text as="span" tone="subdued" variant="bodySm">
                          avg order value
                        </Text>
                      </Text>
                    </BlockStack>
                  </div>
                ))}
              </InlineGrid>
            )}
            <Text as="p" tone="subdued" variant="bodySm">
              Channel classification uses the referring link captured when
              each order was placed. This is only recorded for orders synced
              via webhook after this feature was enabled — older backfilled
              orders show up as "Direct" until a future update re-syncs them.
            </Text>
          </BlockStack>
        </Card>

        <Card>
          <BlockStack gap="300">
            <SectionHeading
              icon={ProductIcon}
              title="Product-wise delivery analysis"
              subtitle="Orders with multiple products appear under each product — totals may exceed the order count above."
            />
            {productDelivery.length === 0 ? (
              <Text as="p" tone="subdued">
                No orders in this range yet.
              </Text>
            ) : (
              <DataTable
                columnContentTypes={["text", "numeric", "numeric", "numeric", "numeric", "numeric"]}
                headings={["Product", "Orders", "In process", "Delivery rate", "RTO rate", "Revenue impact"]}
                rows={productDelivery.map((r) => [
                  r.title,
                  String(r.orders),
                  String(r.inProcess),
                  `${r.deliveryRatePercent.toFixed(1)}%`,
                  r.rtoRatePercent > 20 ? `⚠ ${r.rtoRatePercent.toFixed(1)}%` : `${r.rtoRatePercent.toFixed(1)}%`,
                  money(r.revenueImpact, currency),
                ])}
              />
            )}
          </BlockStack>
        </Card>
      </BlockStack>
    </Page>
  );
}
