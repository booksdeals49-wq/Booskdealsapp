// Resource route (no UI) — streams a downloadable CSV covering everything
// shown on the Reports page: range metrics, the enhanced cost/profit
// breakdown, channel-wise performance, product-wise delivery analysis, and
// a full per-order detail table.

import type { LoaderFunctionArgs } from "@remix-run/node";
import { authenticate } from "../shopify.server";
import prisma from "../db.server";
import { resolveDateRange } from "../utils/dateRange.server";
import { getRangeSummary } from "../services/rangeSummary.server";
import { getCostBreakdown } from "../services/costBreakdown.server";
import { getChannelPerformance } from "../services/channelPerformance.server";
import { getProductDelivery } from "../services/productDelivery.server";
import {
  computeOrderProfit,
  type CostSettings as CostSettingsType,
} from "../services/profit.server";

type OrderRow = {
  orderNumber: string;
  orderId: string;
  totalPrice: number;
  subtotalPrice: number;
  isCod: boolean;
  isRto: boolean;
  lineItemsJson: string;
  city: string | null;
  createdAt: Date;
};

function csvCell(value: string | number): string {
  const s = String(value);
  if (s.includes(",") || s.includes('"') || s.includes("\n")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function csvRow(values: Array<string | number>): string {
  return values.map(csvCell).join(",") + "\r\n";
}

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;

  const url = new URL(request.url);
  const range = resolveDateRange(url);
  const { from, to } = range;

  const [rangeSummary, costBreakdown, channelPerformance, productDelivery, orders, costSettings, productCosts] =
    await Promise.all([
      getRangeSummary(shop, from, to),
      getCostBreakdown(shop, from, to),
      getChannelPerformance(shop, from, to),
      getProductDelivery(shop, from, to),
      prisma.orderRecord.findMany({
        where: { shop, createdAt: { gte: from, lt: to } },
        orderBy: { createdAt: "desc" },
      }),
      prisma.costSettings.upsert({ where: { shop }, update: {}, create: { shop } }),
      prisma.productCost.findMany({ where: { shop } }),
    ]);

  const settings: CostSettingsType = costSettings;
  const overrides = productCosts.map(
    (p: { variantId: string; costPerUnit: number }) => ({
      variantId: p.variantId,
      costPerUnit: p.costPerUnit,
    }),
  );

  const rows = orders as OrderRow[];
  const currency = rangeSummary.currency;
  const generatedAt = new Date().toISOString();

  let csv = "";
  csv += csvRow([`COD Profit Report — ${shop}`]);
  csv += csvRow([`Period: ${range.fromLabel} to ${range.toLabel}`]);
  csv += csvRow([`Generated: ${generatedAt}`]);
  csv += csvRow([`Currency: ${currency}`]);
  csv += "\r\n";

  csv += csvRow(["Range Metrics"]);
  csv += csvRow(["Total orders", rangeSummary.orderCount]);
  csv += csvRow(["Returned (RTO)", rangeSummary.rtoCount]);
  csv += csvRow(["RTO rate %", rangeSummary.rtoRatePercent.toFixed(2)]);
  csv += csvRow(["Total revenue (gross)", rangeSummary.grossRevenue.toFixed(2)]);
  csv += csvRow(["Average order value", rangeSummary.aov.toFixed(2)]);
  csv += csvRow(["Returns value (lost)", rangeSummary.returnsAmount.toFixed(2)]);
  csv += csvRow(["Net profit (realized, after ad spend)", rangeSummary.netProfitAfterAdSpend.toFixed(2)]);
  csv += csvRow(["Profit per order", rangeSummary.profitPerOrder.toFixed(2)]);
  csv += csvRow(["Total costs (incl. ad spend)", costBreakdown.totalCostsInclAdSpend.toFixed(2)]);
  csv += csvRow(["Gross ROAS", rangeSummary.roas.grossRoas.toFixed(2)]);
  csv += csvRow(["True ROAS (COD-adjusted)", rangeSummary.roas.trueRoas.toFixed(2)]);
  csv += csvRow(["Total ad spend", rangeSummary.totalAdSpend.toFixed(2)]);
  csv += csvRow(["Blended CAC", rangeSummary.blendedCac.toFixed(2)]);
  csv += "\r\n";

  csv += csvRow(["Costs Breakdown"]);
  csv += csvRow(["Product costs (COGS) — total", costBreakdown.totalCogs.toFixed(2)]);
  costBreakdown.cogsByCountry.forEach((row) => {
    csv += csvRow([`  ${row.country} — Total COGS`, row.totalCogs.toFixed(2)]);
    csv += csvRow([`  ${row.country} — Returned COGS`, row.returnedCogs.toFixed(2)]);
    csv += csvRow([`  ${row.country} — Final COGS (used)`, row.finalCogsUsed.toFixed(2)]);
  });
  csv += csvRow(["Cash handling / payment fees", costBreakdown.cashHandlingFees.toFixed(2)]);
  csv += csvRow(["Delivery fees", costBreakdown.deliveryFees.toFixed(2)]);
  csv += csvRow(["RTO shipping costs", costBreakdown.rtoCosts.toFixed(2)]);
  csv += csvRow(["Taxes", costBreakdown.taxes.toFixed(2)]);
  csv += csvRow(["Packaging fees", costBreakdown.packagingFees.toFixed(2)]);
  csv += csvRow(["Ad spend — total", costBreakdown.totalAdSpend.toFixed(2)]);
  costBreakdown.adSpendByPlatform.forEach((row) => {
    csv += csvRow([`  ${row.platform}`, row.spend.toFixed(2)]);
  });
  csv += csvRow(["Total costs (incl. ad spend)", costBreakdown.totalCostsInclAdSpend.toFixed(2)]);
  csv += "\r\n";

  csv += csvRow(["Net Profit (Realized) Breakdown"]);
  csv += csvRow(["Delivered GMV (starting point)", costBreakdown.deliveredGmv.toFixed(2)]);
  csv += csvRow(["- Final COGS (used)", (-costBreakdown.finalCogsUsed).toFixed(2)]);
  csv += csvRow(["- Cash handling / payment fees", (-costBreakdown.cashHandlingFees).toFixed(2)]);
  csv += csvRow(["- Delivery fees", (-costBreakdown.deliveryFees).toFixed(2)]);
  csv += csvRow(["- RTO shipping costs", (-costBreakdown.rtoCosts).toFixed(2)]);
  csv += csvRow(["- Taxes", (-costBreakdown.taxes).toFixed(2)]);
  csv += csvRow(["- Packaging fees", (-costBreakdown.packagingFees).toFixed(2)]);
  csv += csvRow(["- Ad spend", (-costBreakdown.totalAdSpend).toFixed(2)]);
  csv += csvRow(["= Net profit (realized)", costBreakdown.netProfitAfterAdSpend.toFixed(2)]);
  csv += "\r\n";

  csv += csvRow(["Channel-wise Performance"]);
  csv += csvRow(["Channel", "Orders", "Delivered", "RTO", "Delivery rate %", "RTO rate %", "Avg order value"]);
  channelPerformance.forEach((r) => {
    csv += csvRow([
      r.channel,
      r.orders,
      r.delivered,
      r.rto,
      r.deliveryRatePercent.toFixed(2),
      r.rtoRatePercent.toFixed(2),
      r.avgOrderValue.toFixed(2),
    ]);
  });
  csv += "\r\n";

  csv += csvRow(["Product-wise Delivery Analysis"]);
  csv += csvRow(["Product", "Orders", "In process", "Delivered", "RTO", "Delivery rate %", "RTO rate %", "Revenue impact"]);
  productDelivery.forEach((r) => {
    csv += csvRow([
      r.title,
      r.orders,
      r.inProcess,
      r.delivered,
      r.rto,
      r.deliveryRatePercent.toFixed(2),
      r.rtoRatePercent.toFixed(2),
      r.revenueImpact.toFixed(2),
    ]);
  });
  csv += "\r\n";

  csv += csvRow(["Order Detail"]);
  csv += csvRow([
    "Order",
    "Date",
    "City",
    "Status",
    "Order total",
    "COGS loss",
    "Delivery fee",
    "RTO fee",
    "Cash handling",
    "Tax",
    "Packaging",
    "Net profit",
    "Margin %",
  ]);
  rows.forEach((o) => {
    const b = computeOrderProfit(
      {
        orderId: o.orderId,
        totalPrice: o.totalPrice,
        subtotalPrice: o.subtotalPrice,
        isCod: o.isCod,
        isRto: o.isRto,
        lineItems: JSON.parse(o.lineItemsJson),
      },
      settings,
      overrides,
    );
    csv += csvRow([
      o.orderNumber,
      new Date(o.createdAt).toISOString().slice(0, 10),
      o.city || "Unknown",
      o.isRto ? "RTO" : "Delivered/active",
      o.totalPrice.toFixed(2),
      b.cogsLoss.toFixed(2),
      b.deliveryFee.toFixed(2),
      b.rtoCost.toFixed(2),
      b.cashHandlingFee.toFixed(2),
      b.tax.toFixed(2),
      b.packagingFee.toFixed(2),
      b.netProfit.toFixed(2),
      b.marginPercent.toFixed(2),
    ]);
  });

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="profitability-report-${range.fromLabel}-to-${range.toLabel}.csv"`,
    },
  });
};
